// Compiled by ClojureScript 1.10.773 {:static-fns true, :optimize-constants true, :elide-asserts true}
goog.provide('process.env');
goog.require('cljs.core');
goog.require('cljs.core.constants');

/**
 * @define {string}
 */
process.env.NODE_ENV = goog.define("process.env.NODE_ENV","development");
